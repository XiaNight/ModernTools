﻿using System.Windows.Controls;
using ModernWpf;
using ModernWpf.Controls;

namespace Base.Components;
/// <summary>
/// Interaction logic for ConfigListField.xaml
/// </summary>
public partial class ConfigListField : UserControl, IConfigEditor
{
    private ConfigItem item;

    public ConfigListField()
    {
        InitializeComponent();
    }

    public void Bind(ConfigItem item)
    {
        this.item = item;
        Type type = item.UnderlyingType;
        Type[] templates = type.GetGenericArguments();
        
        if (item.Get() is not System.Collections.IEnumerable items)
            return;

        foreach (var childItem in items)
        {
            IEnumerable<ConfigItem> childConfigs = ConfigEditorFactory.GetConfigItems(childItem);
            SimpleStackPanel simpleStackPanel = new SimpleStackPanel()
            {
                Orientation = Orientation.Vertical,
                Spacing = 4,
            };
            foreach(ConfigItem childConfig in childConfigs)
            {
                simpleStackPanel.Children.Add(ConfigEditorFactory.CreateEditor(childConfig));
            }
            ContentList.Add(simpleStackPanel);
        }
    }
}
